import React from "react";
import { motion } from "framer-motion";
import { Mail, Instagram, Phone, DownloadCloud } from "lucide-react";

export default function PortfolioWebsite() {
  const meta = {
    name: "Ranjith",
    role: "Mobile Video Editor",
    location: "Salem",
    whatsapp: "+919342386086",
    email: "ranjith.cse25@jit.net.in",
    instagram: "https://www.instagram.com/rv_creationz___",
  };

  const skills = [
    "Short-form editing (Reels/TikTok/Shorts)",
    "Transitions & cinematic cuts",
    "Mobile color grading",
    "Motion text & title animations",
    "Beat-sync editing",
    "Product & brand edits",
  ];

  const services = [
    "Instagram Reels editing",
    "YouTube Shorts editing",
    "Product & promo videos",
    "Event highlight reels",
    "Gaming montages",
    "Monthly content packages",
  ];

  const pricing = [
    { title: "Basic", price: "₹200 / video", items: ["15–20 sec", "Basic cuts", "Light grading"] },
    { title: "Standard", price: "₹400 / video", items: ["20–30 sec", "Transitions", "Text animations"] },
    { title: "Premium", price: "₹700 / video", items: ["30–60 sec", "Advanced transitions", "Motion graphics"] },
  ];

  const sampleVideos = [
    { id: 1, title: "Showreel 1", src: "https://www.youtube.com/embed/dQw4w9WgXcQ" },
    { id: 2, title: "Reel Sample", src: "https://www.youtube.com/embed/dQw4w9WgXcQ" },
    { id: 3, title: "Shorts Sample", src: "https://www.youtube.com/embed/dQw4w9WgXcQ" },
  ];

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 antialiased">
      <header className="max-w-5xl mx-auto p-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">{meta.name}</h1>
          <p className="text-sm text-gray-600">{meta.role} • {meta.location}</p>
        </div>
        <div className="flex items-center gap-3">
          <a href={`https://wa.me/${meta.whatsapp.replace(/[+\s]/g, "")}`} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white shadow-sm hover:shadow-md">
            <Phone size={16} />
            <span className="text-sm">WhatsApp</span>
          </a>
          <a href={`mailto:${meta.email}`} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white shadow-sm hover:shadow-md">
            <Mail size={16} />
            <span className="text-sm">Email</span>
          </a>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-6 space-y-10">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <motion.div initial={{ x: -30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="bg-white p-6 rounded-2xl shadow">
            <h2 className="text-3xl font-bold">Hi — I’m {meta.name}.</h2>
            <p className="mt-4 text-gray-700">A mobile-first video editor creating attention-grabbing short-form content for creators and small brands. I specialize in Reels, TikToks, and YouTube Shorts that get views.</p>

            <div className="mt-6 space-y-3">
              <a href={meta.instagram} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-pink-500 to-yellow-400 text-white font-semibold shadow">
                <Instagram size={16} /> Visit Instagram
              </a>
              <a href={`https://wa.me/${meta.whatsapp.replace(/[+\s]/g, "")}`} className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-200">
                Message on WhatsApp
              </a>
            </div>
          </motion.div>

          <motion.div initial={{ x: 30, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="bg-white p-6 rounded-2xl shadow">
            <h3 className="text-lg font-semibold">Quick Contact</h3>
            <ul className="mt-3 space-y-2 text-sm text-gray-700">
              <li><strong>WhatsApp:</strong> {meta.whatsapp}</li>
              <li><strong>Email:</strong> {meta.email}</li>
              <li><strong>Instagram:</strong> <a href={meta.instagram} className="text-blue-600 underline" target="_blank" rel="noreferrer">@rv_creationz___</a></li>
            </ul>

            <div className="mt-6 flex gap-3">
              <a href={`mailto:${meta.email}?subject=Video%20Editing%20Enquiry&body=Hi%20Ranjith,`} className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-white shadow-sm hover:shadow-md">
                <Mail size={16} /> Hire me
              </a>
              <a href="#pricing" className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-yellow-400 text-white font-semibold">
                <DownloadCloud size={16} /> Pricing
              </a>
            </div>
          </motion.div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl shadow">
            <h4 className="text-lg font-semibold">Skills</h4>
            <ul className="mt-4 space-y-2 text-sm text-gray-700">
              {skills.map((s) => (
                <li key={s} className="inline-flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-gray-800" /> {s}</li>
              ))}
            </ul>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow md:col-span-2">
            <h4 className="text-lg font-semibold">Services</h4>
            <div className="mt-4 flex flex-wrap gap-3">
              {services.map((svc) => (
                <span key={svc} className="px-3 py-1 text-sm rounded-full border">{svc}</span>
              ))}
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-bold">Portfolio / Samples</h3>
          <p className="text-sm text-gray-600 mt-1">Click any sample to open.</p>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {sampleVideos.map((v) => (
              <div key={v.id} className="bg-white rounded-2xl shadow overflow-hidden">
                <div className="aspect-video bg-black">
                  <iframe className="w-full h-full" src={v.src} title={v.title} frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                </div>
                <div className="p-4">
                  <h5 className="font-semibold">{v.title}</h5>
                  <p className="text-sm text-gray-600 mt-2">Short description or client name (replace with real data).</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="pricing">
          <h3 className="text-2xl font-bold">Pricing</h3>
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            {pricing.map((p) => (
              <div key={p.title} className="bg-white p-6 rounded-2xl shadow">
                <h4 className="text-lg font-semibold">{p.title}</h4>
                <p className="mt-2 text-xl font-bold">{p.price}</p>
                <ul className="mt-4 space-y-2 text-sm text-gray-600">
                  {p.items.map((it) => <li key={it}>• {it}</li>)}
                </ul>
                <a href={`mailto:${meta.email}?subject=Booking%20${encodeURIComponent(p.title)}`} className="mt-4 inline-block px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold">Book {p.title}</a>
              </div>
            ))}
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-bold">Why work with me?</h3>
          <div className="mt-4 bg-white p-6 rounded-2xl shadow text-gray-700">
            <ul className="list-disc pl-5 space-y-2">
              <li>Fast turnaround and quick revisions</li>
              <li>Mobile-first workflow — quick edits delivered from phone</li>
              <li>Affordable pricing and monthly packages</li>
            </ul>
          </div>
        </section>

        <section>
          <h3 className="text-2xl font-bold">Contact</h3>
          <div className="mt-4 bg-white p-6 rounded-2xl shadow">
            <form action={`mailto:${meta.email}`} method="GET" className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input name="subject" placeholder="Subject" className="p-3 border rounded" />
              <input name="body" placeholder="Write your message or brief" className="p-3 border rounded" />
              <div className="md:col-span-2 flex gap-3">
                <button type="submit" className="px-4 py-2 bg-green-500 text-white rounded-lg">Send Email</button>
                <a href={meta.instagram} target="_blank" rel="noreferrer" className="px-4 py-2 border rounded-lg">Instagram</a>
                <a href={`https://wa.me/${meta.whatsapp.replace(/[+\s]/g, "")}`} className="px-4 py-2 border rounded-lg">WhatsApp</a>
              </div>
            </form>
          </div>
        </section>
      </main>

      <footer className="mt-12 border-t py-6">
        <div className="max-w-5xl mx-auto px-6 flex items-center justify-between">
          <p className="text-sm text-gray-600">© {new Date().getFullYear()} Ranjith — Mobile Video Editor</p>
          <div className="flex items-center gap-3 text-sm text-gray-600">
            <a href={meta.instagram} target="_blank" rel="noreferrer">Instagram</a>
            <a href={`mailto:${meta.email}`} className="ml-4">Email</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
